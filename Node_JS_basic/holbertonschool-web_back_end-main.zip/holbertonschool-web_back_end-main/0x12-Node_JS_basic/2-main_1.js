const countStudents = require('./2-read_file');

countStudents("database.csv");
