function displayMessage(string) {
  console.log(string);
}

module.exports = displayMessage;
