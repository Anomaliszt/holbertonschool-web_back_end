import groceriesList from './9-groceries_list.js';

console.log(groceriesList());
