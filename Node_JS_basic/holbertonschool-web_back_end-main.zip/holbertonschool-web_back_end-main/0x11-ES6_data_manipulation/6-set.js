function setFromArray(array) {
  const set = new Set(array);
  return set;
}

export default setFromArray;
