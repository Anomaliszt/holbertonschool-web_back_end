#!/usr/bin/env python3
''' Description: Define and annotate the following variables with the
    specified values
    Arguments:  a - integer with value 1
                pi - float with value 3.14
                i_understand_annotations - boolean with value True
                school - str with value 'Holberton'
'''


a: int = 1
pi: float = 3.14
i_understand_annotations: bool = True
school: str = 'Holberton'
