import listOfStudents from './9-hoisting.js';

console.log(listOfStudents);
