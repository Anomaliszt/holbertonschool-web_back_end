export default function returnHowManyArguments(...input) {
	return input.length;
}
