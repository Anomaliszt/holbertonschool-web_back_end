import uploadPhoto from './5-photo-reject';

console.log(uploadPhoto('guillaume.jpg'));
